import java.util.Scanner;

public class Q3 {
    static char[] arr(String s) {
        char[] a = new char[s.length()];

        for (int i = 0; i < s.length(); i++)
            a[i] = s.charAt(i);

        return a;
    }

    static boolean cmp(char[] a, char[] b) {
        if (a.length != b.length)
            return false;

        for (int i = 0; i < a.length; i++) {
            if (a[i] != b[i])
                return false;
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String t = s.next();

        char[] a = arr(t);
        char[] b = t.toCharArray();

        System.out.println("Same: " + cmp(a, b));
    }
}